/**
 * Enumerate four directions
 */

package ca.MazeGame.supporters;

public enum Direction {
	UP, DOWN, RIGHT, LEFT;
}
